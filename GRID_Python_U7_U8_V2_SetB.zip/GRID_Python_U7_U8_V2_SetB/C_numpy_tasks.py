# Section C - Q7 to Q10
import numpy as np

# Q7. Creating arrays and slicing
a = np.arange(5, 56, 5)
print(a)

zeros = np.zeros((2, 6))
ones = np.ones((3, 3), dtype=float)
print(zeros.shape, ones.shape, ones.sum())

print(np.eye(3) * 6)

lin = np.linspace(0, 10, 50)
print(len(lin), round(float(lin[1]), 4), float(lin[-1]))

np.random.seed(3)
r = np.random.randint(1, 21, size=(4, 4))
print(r)
r[0] = 100
print(r[0])
print(r[-2:, -2:])

# Q8. Boolean masks, np.where and views
ages = np.array([19, 42, 16, 28, 33, 15, 51])
print(ages[ages >= 18])
print(ages[(ages > 25) & (ages < 45)])
print(ages[~(ages >= 18)])

scores = np.array([48, 91, 66, 73, 59, 85])
print(np.where(scores >= 70, "Pass", "Fail"))

temps = np.array([31, 27, 36, 40, 29, 33])
mask = temps > 35
temps[mask] = 34
print(temps, int(mask.sum()))

mat = np.arange(3, 28).reshape(5, 5)
print(mat[1:4, 2:5])
view = mat[0]
view[0] = 99
print(mat[0, 0])
copy = mat[1].copy()
copy[0] = -1
print(mat[1, 0])
# A view shares the original array's memory; a copy is independent.

# Q9. Array maths and statistics
A = np.arange(3, 12).reshape(3, 3)
B = np.arange(11, 20).reshape(3, 3)
print(A * B)
print(np.round(A / B, 2))
print(A @ B)

arr = np.array([5, 15, 25, 35, 45], dtype=float)
z_scores = (arr - arr.mean()) / arr.std()
print(np.round(z_scores, 2), round(float(z_scores.mean()), 6))

p = np.array([1, 2, 2])
q = np.array([4, 6, 14])
print(float(np.sqrt(np.sum((p - q) ** 2))))

v = np.array([8, 3, 19, 11, 6, 2])
print(np.argmax(v), np.argmin(v), v.max(), v.min())
print(float(v.mean()), float(np.median(v)), round(float(v.var()), 2),
      round(float(v.std()), 2))

m = np.array([[9, 3, 1], [6, 8, 2], [5, 7, 4]])
print(np.sort(m, axis=0))
print(np.sort(m, axis=1))

pn = np.array([4, -2, 0, 9, -6, 0, 3, -1])
print(int((pn > 0).sum()), int((pn < 0).sum()), int((pn == 0).sum()))

# Q10. Reshape, broadcasting and splitting
vals = np.arange(1, 16)
print(vals.reshape(5, -1).shape)
print(vals.reshape(3, 5).flatten().tolist() == vals.tolist())

sales = np.array([[30, 10], [20, 40], [15, 25]])
bonus = np.array([5, 1, 4])[:, np.newaxis]
print(sales + bonus)
rates = np.array([0.2, 0.1])
print(np.round(sales * rates, 2))

arr = np.arange(1, 15)
try:
    np.split(arr, 3)
except ValueError:
    print("ValueError")
parts = np.array_split(arr, 3)
print([part.tolist() for part in parts])
