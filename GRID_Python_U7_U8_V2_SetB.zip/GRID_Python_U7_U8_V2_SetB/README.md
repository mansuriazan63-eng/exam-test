# GRID Python Units 7 & 8 - Practical Test Set B

**Name:** Your Name  
**GRID:** Your GRID

## Sections Practised
- **Section A:** Date/time handling, math, random values, UUIDs and performance timing.
- **Section B:** File and folder operations, custom modules, `__name__`, packages and sub-packages.
- **Section C:** NumPy arrays, slicing, boolean masks, statistics, broadcasting and splitting.
- **Section D:** Pandas Series/DataFrames, CSV cleaning, filtering, grouping, merging and JSON.

## Two Hardest Topics
1. **Python packages and imports:** I solved this by creating the required folder structure and testing the package entry point.
2. **Pandas cleaning and grouping:** I solved this by practising `drop_duplicates`, missing-value handling, `groupby`, `transform` and `merge`.

## Project Structure
```text
GRID_Python_U7_U8_V2_SetB/
├── README.md
├── A_standard_modules.py
├── B_os_demo.py
├── scoretools.py
├── B_main_module.py
├── textkit/
│   ├── __init__.py
│   ├── clean.py
│   ├── stats.py
│   └── extra/
│       ├── __init__.py
│       └── frame.py
├── B_main_package.py
├── C_numpy_tasks.py
├── D_pandas_tasks.py
├── students.csv
├── mentors.csv
├── names.json        # generated when D_pandas_tasks.py runs
└── Screenshots/
    ├── A_Standard_Modules.png
    ├── B_Modules_Packages.png
    ├── C_NumPy.png
    └── D_Pandas.png
```

## Requirements
- Python 3
- NumPy
- Pandas

Install the libraries if required:
```bash
python -m pip install numpy pandas
```

## How to Run
Run these commands from the project folder:
```bash
python A_standard_modules.py
python B_os_demo.py
python scoretools.py
python B_main_module.py
python B_main_package.py
python C_numpy_tasks.py
python D_pandas_tasks.py
```

`D_pandas_tasks.py` reads `students.csv` and `mentors.csv` from the same folder and creates `names.json`.

## Screenshots
Run each section, then capture the code and its output in your editor/terminal. Save the four genuine screenshots in `Screenshots/` using the exact filenames listed above.

## GitHub Submission
Create a public repository named `GRID_Python_U7_U8_V2_SetB`, then upload this folder. Make at least three meaningful commits, for example:
- Add Section A standard module solutions
- Add Section B modules and packages
- Add NumPy and Pandas solutions
