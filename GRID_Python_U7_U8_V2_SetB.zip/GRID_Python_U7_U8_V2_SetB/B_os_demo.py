# Section B - Q4
import os
import shutil

root = "exam_data"
logs = os.path.join(root, "logs")
archive = os.path.join(root, "archive")

os.makedirs(logs, exist_ok=True)
os.makedirs(logs, exist_ok=True)

with open(os.path.join(logs, "x.txt"), "w", encoding="utf-8") as file:
    file.write("one\ntwo\n")
with open(os.path.join(logs, "y.txt"), "w", encoding="utf-8") as file:
    file.write("three\n")
with open(os.path.join(logs, "z.csv"), "w", encoding="utf-8") as file:
    file.write("x,y\n1,2\n")

print(sorted(name for name in os.listdir(logs) if name.endswith(".txt")))

with open(os.path.join(logs, "x.txt"), encoding="utf-8") as file:
    lines = file.readlines()
print(len(lines), lines[0].strip())

os.makedirs(archive, exist_ok=True)
shutil.move(os.path.join(logs, "x.txt"), os.path.join(archive, "x.txt"))
print(sorted(os.listdir(logs)), sorted(os.listdir(archive)))

os.rename(os.path.join(logs, "y.txt"), os.path.join(logs, "old_y.txt"))
print(os.path.exists(os.path.join(logs, "y.txt")),
      os.path.isfile(os.path.join(logs, "old_y.txt")))

shutil.rmtree(root)
print(os.path.exists(root))
