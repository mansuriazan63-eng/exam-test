def tidy(text):
    return " ".join(word.capitalize() for word in text.split())

def slug(text):
    return "-".join(text.lower().split())
