def word_count(text):
    return len(text.split())

def longest_word(text):
    words = text.split()
    return max(words, key=len) if words else ""
