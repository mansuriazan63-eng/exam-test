def box(text):
    return f"[{text}]"

def underline(text):
    return text + "\n" + "-" * len(text)
