# Section A - Q1 to Q3
from datetime import datetime, timedelta, timezone
import math
import random
import uuid
import time

# Q1. Date and time
def is_leap_year(year):
    if year % 400 == 0:
        return True
    if year % 100 == 0:
        return False
    return year % 4 == 0

for year in [1800, 2012, 2025, 2400, 2028]:
    print(year, is_leap_year(year))

def day_of_week(text):
    date_obj = datetime.strptime(text, "%Y-%m-%d")
    return date_obj.strftime("%A")

for date_text in ["2026-02-14", "2026-08-15", "2027-01-26"]:
    print(date_text, day_of_week(date_text))

start = datetime(2026, 2, 1)
end = datetime(2026, 11, 30)
print((end - start).days)

now = datetime(2026, 7, 19, 9, 5, 30)
print(now.strftime("%d-%m-%Y"), now.strftime("%m/%d/%Y"))
print(now.strftime("%H:%M:%S"), now.strftime("%I:%M:%S %p"))
future = now + timedelta(weeks=3, days=2, hours=7)
print(future.strftime("%Y-%m-%d %H:%M:%S"))

# Q2. Math and random
print(math.ceil(83 / 12))

seconds = 5461
hours = seconds // 3600
minutes = (seconds % 3600) // 60
remaining_seconds = seconds % 60
print(hours, minutes, remaining_seconds)

def simplify(n, d):
    divisor = math.gcd(n, d)
    return (n // divisor, d // divisor)

print(simplify(45, 60))
distance = 80
angle = math.radians(45)
print(round(distance * math.tan(angle), 2))

random.seed(5)
rolls = [random.randint(1, 6) for _ in range(5)]
print(rolls, sum(rolls))
deck = list(range(1, 9))
random.shuffle(deck)
print(deck)
print(random.choice(["rock", "paper", "scissors"]))

# Q3. UUID and time
names = ["Neha", "Imran", "Dev", "Sana"]
ids = {
    name: uuid.uuid5(uuid.NAMESPACE_DNS, name.lower() + ".example")
    for name in names
}
for name, identifier in ids.items():
    print(name, str(identifier)[:8])
print(len(set(ids.values())) == len(ids))

uuid3_value = uuid.uuid3(uuid.NAMESPACE_DNS, "example.com")
uuid5_value = uuid.uuid5(uuid.NAMESPACE_DNS, "example.com")
print(uuid3_value != uuid5_value, uuid3_value.version, uuid5_value.version)

ts = 1000000000
utc_struct = time.gmtime(ts)
print(time.strftime("%Y-%m-%d %H:%M:%S", utc_struct))
print(time.asctime(utc_struct))
print(datetime.fromtimestamp(ts, timezone.utc).strftime("%d %b %Y"))

before = time.perf_counter()
total = sum(range(1_000_000))
elapsed = time.perf_counter() - before
print(total, type(elapsed).__name__, elapsed >= 0)
