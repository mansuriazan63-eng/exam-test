# Section D - Q11 to Q15
import pandas as pd

# Q11. Series, DataFrame and exploring a CSV
s = pd.Series(["Student_1", "Student_2", "Student_3"], index=["a", "b", "c"])
print(s["b"], s.iloc[2], len(s))

items = pd.DataFrame([
    {"item": "pen", "qty": 10},
    {"item": "book", "qty": 4},
    {"item": "bag", "qty": 2},
])
print(items)

df = pd.read_csv("students.csv")
print(df.head(3))
print(df.shape, list(df.columns))
print(df.duplicated().sum())
print(df.isna().sum())

# Q12. Clean and convert
df = df.drop_duplicates()
df["Scholarship"] = pd.to_numeric(df["Scholarship"], errors="coerce").fillna(0).astype(int)
fees_fill = int(round(df["Fees"].mean()))
df["Fees"] = df["Fees"].fillna(fees_fill).astype(int)
df["AdmitDate"] = pd.to_datetime(df["AdmitDate"])
df["Year"] = df["AdmitDate"].dt.year
df["Weekday"] = df["AdmitDate"].dt.day_name()
df["Years"] = ((pd.Timestamp("2026-01-01") - df["AdmitDate"]).dt.days // 365)
print(fees_fill, df.shape, df["Fees"].dtype, df["Scholarship"].dtype)
print(df[["StudentID", "Year", "Weekday", "Years"]].head(4))

# Q13. New column, filtering, indexing and categories
df["Payable"] = df["Fees"] + df["Scholarship"]
filtered = df[(df["Course"] == "Data") & (df["Payable"] > 40000)]
print(filtered[["StudentID", "Name", "Payable"]])
print(type(df["Name"]).__name__, type(df[["Name"]]).__name__)
print(df.loc[0, "Name"], df.iloc[1, 1])

def band(n):
    if n >= 48000:
        return "High"
    if n >= 35000:
        return "Mid"
    return "Low"

df["Band"] = df["Payable"].apply(band)
df["Band"] = pd.Categorical(df["Band"], categories=["Low", "Mid", "High"], ordered=True)
sorted_df = df.sort_values(["Band", "StudentID"], ascending=[False, True])
print(sorted_df[["StudentID", "Band"]].head(3))
print(df["Band"].value_counts().sort_index())

# Q14. Grouping and pivot table
grouped = df.groupby("Course")["Fees"].agg(["mean", "max", "count"])
grouped["mean"] = grouped["mean"].round(1)
print(grouped.sort_values("mean", ascending=False))

group_totals = df.groupby("Course")["Fees"].transform("sum")
df["PctOfGroup"] = (df["Fees"] / group_totals * 100).round(1)
print(df[["StudentID", "Course", "PctOfGroup"]].head(4))

pivot = pd.pivot_table(df, values="Fees", index="Course", columns="City",
                       aggfunc="sum", fill_value=0)
print(pivot)

# Q15. Merge, index and JSON
mentors = pd.read_csv("mentors.csv")
left = df.merge(mentors, on="Course", how="left")
inner = df.merge(mentors, on="Course", how="inner")
outer = df.merge(mentors, on="Course", how="outer")
print(left["Mentor"].isna().sum(), left.shape)
print(len(inner), len(outer))

emp = df.set_index("StudentID")
print(emp.loc[308, "Name"])
reset = emp.reset_index().rename(columns={"Fees": "Monthly Fees"})
print(list(reset.columns[:6]))

df[["StudentID", "Name"]].to_json("names.json", orient="records")
names_back = pd.read_json("names.json")
print(names_back.shape)
