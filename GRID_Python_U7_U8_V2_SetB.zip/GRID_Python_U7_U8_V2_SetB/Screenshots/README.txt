Place your four actual screenshots here after running each section. Do not submit placeholder images.
