# Q5 - Main module
import scoretools
from scoretools import grade, PASS_MARK
import scoretools as sc

print(scoretools.average([55, 65, 72]))
print(grade(52), PASS_MARK)
print(sc.grade(sc.average([90, 85, 95])))
print(sorted(name for name in dir(scoretools) if not name.startswith("_")))
print(scoretools.__name__)
# The guard runs only when scoretools.py is executed directly, not when imported.
print(__name__)
