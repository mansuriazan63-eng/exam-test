# Q6 - Package and sub-package
import textkit
import textkit.clean
import textkit.stats as ts
from textkit.extra.frame import box, underline

print(textkit.VERSION)
print(textkit.tidy(" hello python world "))
print(textkit.clean.slug("Data Science Lab"))
print(ts.word_count("python is fun"), ts.longest_word("learn modules today"))
print(box("ok"))
print(underline("Title"))

# __init__.py marks a directory as a package and can run initialization code
# and expose selected names when the package is imported.
